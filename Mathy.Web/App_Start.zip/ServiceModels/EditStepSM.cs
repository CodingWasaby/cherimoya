﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Mathy.Web.ServiceModels
{
    public class EditStepSM
    {
        public int Index { get; set; }

        public string EditID { get; set; }

        public string Title { get; set; }

        public string Description { get; set; }

        public string Expression { get; set; }

        public string Condition { get; set; }
    }
}